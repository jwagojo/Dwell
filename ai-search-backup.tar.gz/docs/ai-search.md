# Natural-language charger search

The Search page accepts a destination, time, total USD budget, estimated walking limit, charger level, and best-fit/price sort in one description. A language model (GPT-6 Luna on OpenAI, or a local Ollama model during development) extracts typed filters; the existing search and pricing engines evaluate real listings. The selected car continues to control compatibility and pricing. Unsupported or ambiguous requests produce a clarification without changing filters. Multiple address matches require a destination choice.

On the Search page it is a **Describe your plans** button over the top-left corner of the map. It opens a small panel (Enter searches, Escape or the close button dismisses it). A successful search applies the filters and collapses the panel; anything the driver has to fix, such as a clarification or an ambiguous destination, keeps it open.

## Local development

Choose one provider and add its **server-only** variables to the git-ignored `.env` or `.env.local`, then restart `npm run dev`.

**Ollama (local, free).** Install [Ollama](https://ollama.com), pull a model, and keep it running (the Ollama app, or `ollama serve`):

```sh
ollama pull qwen3:8b
```

```dotenv
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=qwen3:8b
```

When `OLLAMA_BASE_URL` is set, development always uses Ollama and ignores any OpenAI key; remove or comment it out to use OpenAI. The service calls Ollama's native `/api/chat` with `think: false`, the intent schema as the `format`, and temperature 0. The first search after Ollama starts loads the model and can take several seconds; the model then stays loaded for 30 minutes. A small local model follows the rules less reliably than a hosted one, so check results: the application still enforces the product rules (today only, whole hours, valid ranges) in code, and ambiguous requests ask for clarification instead of changing filters. Ollama is for local development only, because a deployed Lambda cannot reach `localhost`.

**OpenAI.** Create an API key at <https://platform.openai.com/api-keys>. The API is billed separately from a ChatGPT subscription, so add credits or a payment method under Billing and set a low monthly limit.

```dotenv
OPENAI_API_KEY=<your OpenAI API key>
# Optional. Defaults shown.
# OPENAI_MODEL=gpt-6-luna
# OPENAI_BASE_URL=https://api.openai.com/v1
# OPENAI_REASONING_EFFORT=none
```

The local app calls `/__dev/search/parse`, a Vite server middleware restricted to loopback and same-origin JSON requests. This applies even when `public/config.json` connects sign-in, listings, and bookings to a deployed AWS backend. For OpenAI it reads the key on the server and calls the Chat Completions API with a strict JSON schema, reasoning effort `none`, and `store: false`. No credential is sent to the browser. Do not prefix these settings with `VITE_`. Preview/static production builds do not include the local endpoint.

`OPENAI_BASE_URL` accepts any OpenAI-compatible endpoint (https, or http on localhost), and `OPENAI_MODEL` any model that supports strict `json_schema` output. Set `OPENAI_REASONING_EFFORT=` (empty) for a model that rejects the `reasoning_effort` parameter.

If the page says "Search assistance is unavailable", the browser is intentionally shown a generic message. The `npm run dev` terminal prints the real cause as `[ai-search] <Ollama|OpenAI> responded <status>: <message>` (or `Could not reach <provider>`). Only the status and the provider's short error message are printed, never the search text or key. Common causes:

- Ollama `Could not reach Ollama (ECONNREFUSED)`: Ollama is not running. Start the app or run `ollama serve`.
- Ollama `404 model ... not found`: run `ollama pull <OLLAMA_MODEL>`, or fix the name (see `ollama list`).
- `401`: the key is wrong or revoked.
- `429` with `insufficient_quota`: the account has no credits. Add billing.
- `404` or `400` mentioning the model: the model name is unavailable to this account, or does not support strict JSON output or `reasoning_effort`.

If localhost reports a CORS error for the deployed `/search/parse` URL, restart the dev server and refresh the page: development AI requests should go to the local `/__dev/search/parse` route. Production builds still require deploying the new API route, creating its SSM key parameter, and allowing the site's exact origin in CDK's `webOrigins` context.

## Deployed backend

The CDK API stack adds Cognito-protected `POST /search/parse`. Its Lambda reads the API key from SSM SecureString `/dwell/<stage>/openai-api-key` for every request, allowing key replacement without redeploying. Create that parameter in the AWS console (or CLI) in the same region as the stack, type SecureString, and put the key as the value:

```sh
aws ssm put-parameter --name /dwell/<stage>/openai-api-key --type SecureString --value '<your OpenAI API key>' --region us-east-2
```

The key is never included in CloudFormation or frontend environment variables. Revoked or exhausted keys produce a recoverable "could not connect" or "busy" message. The Lambda is not in a VPC, so it reaches `api.openai.com` directly.

Deploy the updated API stack through the repository's existing CDK workflow and rebuild the frontend. The existing `/config.json` selects the authenticated API in backend mode. Putting the key only in Amplify Hosting build variables does not configure the Lambda.

The stack sets `OPENAI_MODEL=gpt-6-luna`. The service sends one request with a 20-second timeout; the client has 25 seconds and Lambda has 28 seconds. The first request with a new schema can be slower while the provider compiles it. Failures leave manual search usable.

## Behavior

- Today is determined in `America/New_York`, matching booking rules. Only whole-hour starts and 1–12-hour durations are accepted; future dates, past start hours, and fractional times require clarification.
- Omitted time and duration retain the currently selected window, which remains visible and editable. Omitted budget/walking limits clear the previous extra limits when a new AI search is applied.
- Budgets are checked against the fee-inclusive booking total. “Under $15” is exclusive; “up to $15” is inclusive. Late fees are outside this booking estimate.
- Walks remain labeled estimates: the current engine uses straight-line distance with a detour factor. A walking limit with no destination does not match listings.
- Destination coordinates come from station reference data or address search. The model has no database access and cannot book, change billing, or invent listing results. Selecting a destination recenters the map; browsing still follows visible map bounds.
- Search limits are editable on the Search page and scoped to that page visit. Clear limits restores the ordinary search. Search descriptions and keys are not logged by the parser.

## Verification

`npm test` covers request validation, authentication, SSM key retrieval, strict-output request formatting, model errors/refusals/timeouts, Boston dates, unsupported values, budget boundaries, missing walk data, and ambiguous geocoding. `npm run typecheck`, `npm run build`, and `npm run cdk:synth` validate the application and deployment configuration. Live invocation additionally requires network access and a valid OpenAI API key with model access.

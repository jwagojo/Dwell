import { GetParameterCommand } from '@aws-sdk/client-ssm';
import { ssm } from '../shared/clients';
import { api, HttpError, json, readJson, userId } from '../shared/http';
import { interpretSearch, parseSearchRequest } from './service';

async function openAiKey(): Promise<string> {
  // An environment key supports local server runners; deployed stacks supply only the SSM parameter name.
  const direct = process.env.OPENAI_API_KEY?.trim();
  if (direct) return direct;
  const parameter = process.env.OPENAI_KEY_PARAM;
  if (parameter) {
    try {
      const result = await ssm.send(new GetParameterCommand({ Name: parameter, WithDecryption: true }));
      const key = result.Parameter?.Value?.trim();
      if (key) return key;
    } catch { /* Return a safe configuration error; never log parameter contents. */ }
  }
  throw new HttpError(503, 'AI_NOT_CONFIGURED', 'Search assistance is unavailable. Use the search filters.');
}

export const handler = api(async (event) => {
  userId(event);
  const request = parseSearchRequest(readJson(event));
  const intent = await interpretSearch(request, {
    token: await openAiKey(),
    modelId: process.env.OPENAI_MODEL,
    baseUrl: process.env.OPENAI_BASE_URL,
    reasoningEffort: process.env.OPENAI_REASONING_EFFORT,
  });
  return json(200, { intent });
});

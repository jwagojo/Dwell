import { GetParameterCommand, SSMClient } from '@aws-sdk/client-ssm';
import { mockClient } from 'aws-sdk-client-mock';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { apiEvent, call, NOW, useTestEnv } from '../shared/testing';
import { handler } from './handler';
import { interpretSearch, interpretSearchWithOllama, parseSearchRequest, serviceDate, validateSearchIntent } from './service';
import type { SearchIntent } from '../../src/features/search/searchIntent';

useTestEnv();
const ssm = mockClient(SSMClient);
const request = { query: 'Central Square today from 2 to 5 p.m., under $15 total, within a 10 minute walk', context: { startHour: 14, hours: 3, destinationLabel: null } };
const intent: SearchIntent = { destinationQuery: 'Central Square', date: '2026-10-28', startHour: 14, hours: 3, maxTotalUsd: 15, budgetExclusive: true, maxWalkMinutes: 10, level: null, sort: null, clarification: null };
const response = (value: unknown = intent, finishReason = 'stop', refusal: string | null = null) => new Response(JSON.stringify({ choices: [{ finish_reason: finishReason, message: { role: 'assistant', content: refusal ? null : JSON.stringify(value), refusal } }] }));

beforeEach(() => {
  ssm.reset();
  vi.spyOn(Date, 'now').mockReturnValue(NOW);
  vi.stubEnv('OPENAI_API_KEY', 'test-openai-secret');
  vi.stubEnv('OPENAI_MODEL', 'gpt-6-luna');
  vi.stubEnv('OPENAI_BASE_URL', undefined);
  vi.stubEnv('OPENAI_REASONING_EFFORT', undefined);
});
afterEach(() => { vi.restoreAllMocks(); vi.unstubAllGlobals(); vi.unstubAllEnvs(); });

describe('POST /search/parse', () => {
  it('authenticates, requests strict JSON with reasoning disabled, and returns only the validated intent', async () => {
    const fetchMock = vi.fn().mockResolvedValue(response());
    vi.stubGlobal('fetch', fetchMock);
    expect(await call(handler, apiEvent({ body: request }))).toEqual({ status: 200, body: { intent } });
    const [url, init] = fetchMock.mock.calls[0];
    expect(url).toBe('https://api.openai.com/v1/chat/completions');
    expect(init.headers.authorization).toBe('Bearer test-openai-secret');
    const payload = JSON.parse(init.body);
    expect(payload.model).toBe('gpt-6-luna');
    expect(payload.reasoning_effort).toBe('none');
    expect(payload.store).toBe(false);
    expect(payload.response_format).toMatchObject({ type: 'json_schema', json_schema: { name: 'charging_search', strict: true, schema: { additionalProperties: false } } });
    expect(payload.messages[0].role).toBe('system');
    expect(JSON.parse(payload.messages[1].content)).toMatchObject({ currentDate: '2026-10-28', timeZone: 'America/New_York', query: request.query });
  });

  it('rejects an unauthenticated or invalid request before invoking the model', async () => {
    const fetchMock = vi.fn();
    vi.stubGlobal('fetch', fetchMock);
    expect((await call(handler, apiEvent({ sub: null, body: request }))).status).toBe(401);
    for (const body of [{ ...request, query: ' ' }, { ...request, query: 'x'.repeat(1001) }, { ...request, context: { ...request.context, hours: 99 } }]) {
      expect((await call(handler, apiEvent({ body }))).status).toBe(400);
    }
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it('reads a deployed token from SSM on each request so replacement does not require deployment', async () => {
    vi.stubEnv('OPENAI_API_KEY', '');
    vi.stubEnv('OPENAI_KEY_PARAM', '/dwell/test/openai-api-key');
    ssm.on(GetParameterCommand).resolves({ Parameter: { Value: 'ssm-secret' } });
    const fetchMock = vi.fn().mockResolvedValue(response());
    vi.stubGlobal('fetch', fetchMock);
    expect((await call(handler, apiEvent({ body: request }))).status).toBe(200);
    expect(ssm.commandCalls(GetParameterCommand)[0].args[0].input).toEqual({ Name: '/dwell/test/openai-api-key', WithDecryption: true });
    expect(fetchMock.mock.calls[0][1].headers.authorization).toBe('Bearer ssm-secret');
  });

  it('handles missing credentials without exposing configuration or calling the provider', async () => {
    vi.stubEnv('OPENAI_API_KEY', '');
    vi.stubEnv('OPENAI_KEY_PARAM', '');
    const fetchMock = vi.fn();
    vi.stubGlobal('fetch', fetchMock);
    expect(await call(handler, apiEvent({ body: request }))).toMatchObject({ status: 503, body: { error: { code: 'AI_NOT_CONFIGURED' } } });
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it.each([401, 403, 429, 500])('returns a safe error for upstream status %s', async (status) => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response('sensitive upstream content test-openai-secret', { status })));
    const result = await call(handler, apiEvent({ body: request }));
    expect(result.status).toBe(status === 429 ? 429 : status === 500 ? 502 : 503);
    expect(JSON.stringify(result.body)).not.toContain('test-openai-secret');
    expect(JSON.stringify(result.body)).not.toContain('sensitive upstream');
  });

  it.each([
    ['missing fields', { destinationQuery: 'Central' }, 'end_turn'],
    ['unknown keys', { ...intent, price: 0 }, 'end_turn'],
    ['wrong types', { ...intent, maxTotalUsd: '15' }, 'end_turn'],
    ['truncated response', intent, 'length'],
    ['content filter', intent, 'content_filter'],
  ])('rejects %s', async (_name, value, finishReason) => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(response(value, finishReason as string)));
    expect((await call(handler, apiEvent({ body: request }))).status).toBe(502);
  });

  it('rejects a model refusal and an empty answer', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(response(intent, 'stop', 'I cannot help with that.')));
    expect((await call(handler, apiEvent({ body: request }))).status).toBe(502);
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response(JSON.stringify({ choices: [] }))));
    expect((await call(handler, apiEvent({ body: request }))).status).toBe(502);
  });

  it('honours a custom endpoint, model, and reasoning setting, and refuses unsafe endpoints', async () => {
    const fetchMock = vi.fn().mockResolvedValue(response());
    vi.stubGlobal('fetch', fetchMock);
    vi.stubEnv('OPENAI_BASE_URL', 'http://localhost:11434/v1/');
    vi.stubEnv('OPENAI_MODEL', 'openai/some-model');
    vi.stubEnv('OPENAI_REASONING_EFFORT', 'low');
    expect((await call(handler, apiEvent({ body: request }))).status).toBe(200);
    expect(fetchMock.mock.calls[0][0]).toBe('http://localhost:11434/v1/chat/completions');
    expect(JSON.parse(fetchMock.mock.calls[0][1].body)).toMatchObject({ model: 'openai/some-model', reasoning_effort: 'low' });

    const noReasoning = vi.fn().mockResolvedValue(response());
    await interpretSearch(request, { token: 'k', fetchImpl: noReasoning as typeof fetch, reasoningEffort: '', now: NOW });
    expect(JSON.parse(noReasoning.mock.calls[0][1].body)).not.toHaveProperty('reasoning_effort');

    for (const baseUrl of ['http://api.example.com/v1', 'https://api.example.com/v1?x=1', 'file:///etc/passwd']) {
      const unused = vi.fn();
      await expect(interpretSearch(request, { token: 'k', baseUrl, fetchImpl: unused as typeof fetch, now: NOW })).rejects.toMatchObject({ status: 503, code: 'AI_NOT_CONFIGURED' });
      expect(unused).not.toHaveBeenCalled();
    }
  });

  it('aborts a stalled model request and returns a recoverable timeout', async () => {
    const fetchImpl = vi.fn((_url: unknown, init?: RequestInit) => new Promise<Response>((_resolve, reject) => {
      init?.signal?.addEventListener('abort', () => reject(new Error('aborted')));
    }));
    await expect(interpretSearch(request, { token: 'fake', fetchImpl: fetchImpl as typeof fetch, timeoutMs: 5, now: NOW })).rejects.toMatchObject({ status: 504, code: 'AI_TIMEOUT' });
  });
});

describe('local Ollama provider', () => {
  const ollamaResponse = (value: unknown = intent, doneReason = 'stop') => new Response(JSON.stringify({ model: 'qwen3:8b', done: true, done_reason: doneReason, message: { role: 'assistant', content: JSON.stringify(value) } }));
  const options = { baseUrl: 'http://localhost:11434/', model: 'qwen3:8b', now: NOW };

  it('calls the native chat API with thinking off and the schema as the output format', async () => {
    const fetchImpl = vi.fn().mockResolvedValue(ollamaResponse());
    expect(await interpretSearchWithOllama(request, { ...options, fetchImpl: fetchImpl as typeof fetch })).toEqual(intent);
    const [url, init] = fetchImpl.mock.calls[0];
    expect(url).toBe('http://localhost:11434/api/chat');
    expect(init.headers).toEqual({ 'content-type': 'application/json' });
    const payload = JSON.parse(init.body);
    expect(payload).toMatchObject({ model: 'qwen3:8b', stream: false, think: false, options: { temperature: 0 }, format: { type: 'object', additionalProperties: false } });
    expect(payload.messages[0].role).toBe('system');
    expect(JSON.parse(payload.messages[1].content)).toMatchObject({ currentDate: '2026-10-28', timeZone: 'America/New_York', query: request.query });
  });

  it.each([
    ['missing fields', { destinationQuery: 'Central' }, 'stop'],
    ['wrong types', { ...intent, maxTotalUsd: '15' }, 'stop'],
    ['truncated response', intent, 'length'],
  ])('rejects %s', async (_name, value, doneReason) => {
    const fetchImpl = vi.fn().mockResolvedValue(ollamaResponse(value, doneReason));
    await expect(interpretSearchWithOllama(request, { ...options, fetchImpl: fetchImpl as typeof fetch })).rejects.toMatchObject({ status: 502 });
  });

  it('still applies the product rules to the local model output', async () => {
    const fetchImpl = vi.fn().mockResolvedValue(ollamaResponse({ ...intent, date: '2026-10-29' }));
    const result = await interpretSearchWithOllama(request, { ...options, fetchImpl: fetchImpl as typeof fetch });
    expect(result.clarification).toMatch(/today only/);
  });

  it('returns safe errors for a missing model, a stopped server, a stall, and unsafe addresses', async () => {
    const missing = vi.fn().mockResolvedValue(new Response('{"error":"model \'qwen3:8b\' not found"}', { status: 404 }));
    await expect(interpretSearchWithOllama(request, { ...options, fetchImpl: missing as typeof fetch })).rejects.toMatchObject({ status: 502, code: 'AI_UNAVAILABLE' });
    const refused = vi.fn().mockRejectedValue(new TypeError('fetch failed'));
    await expect(interpretSearchWithOllama(request, { ...options, fetchImpl: refused as typeof fetch })).rejects.toMatchObject({ status: 502, code: 'AI_UNAVAILABLE' });
    const stalled = vi.fn((_url: unknown, init?: RequestInit) => new Promise<Response>((_resolve, reject) => {
      init?.signal?.addEventListener('abort', () => reject(new Error('aborted')));
    }));
    await expect(interpretSearchWithOllama(request, { ...options, fetchImpl: stalled as typeof fetch, timeoutMs: 5 })).rejects.toMatchObject({ status: 504, code: 'AI_TIMEOUT' });
    for (const baseUrl of ['http://ollama.example.com', 'file:///tmp/x', 'http://localhost:11434?x=1']) {
      const unused = vi.fn();
      await expect(interpretSearchWithOllama(request, { ...options, baseUrl, fetchImpl: unused as typeof fetch })).rejects.toMatchObject({ code: 'AI_NOT_CONFIGURED' });
      expect(unused).not.toHaveBeenCalled();
    }
  });
});

describe('search intent validation', () => {
  it.each([
    ['future date', { date: '2026-10-29' }, /today only/],
    ['fractional start', { startHour: 14.5 }, /whole-hour/],
    ['fractional duration', { hours: 1.5 }, /whole hours/],
    ['too long', { hours: 13 }, /whole hours/],
    ['negative budget', { maxTotalUsd: -1 }, /budget/],
    ['invalid walk', { maxWalkMinutes: 0 }, /walking limit/],
    ['past start', { startHour: 9 }, /already passed/],
  ])('asks for clarification for %s', (_name, patch, message) => {
    expect(validateSearchIntent({ ...intent, ...patch }, request, NOW).clarification).toMatch(message);
  });

  it('uses Boston dates around UTC midnight and retains model clarification', () => {
    expect(serviceDate(Date.parse('2026-10-29T01:00:00Z'))).toBe('2026-10-28');
    expect(validateSearchIntent({ ...intent, clarification: 'Did you mean a.m. or p.m.?' }, request, NOW).clarification).toBe('Did you mean a.m. or p.m.?');
    expect(parseSearchRequest(request)).toEqual(request);
  });
});

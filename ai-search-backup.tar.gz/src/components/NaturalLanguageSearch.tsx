import { useEffect, useRef, useState, type FormEvent } from 'react';
import { parseSearch } from '../adapters/aiSearch';
import type { DwellApi } from '../adapters/dwellApi';
import { resolveSearchDestination } from '../features/search/resolveDestination';
import { isSearchIntent, SEARCH_QUERY_MAX_LENGTH, type SearchContext, type SearchIntent } from '../features/search/searchIntent';
import type { Destination } from '../types/destination';
import { CONTROL } from './form';
import { Close, Sparkle, Warn } from './Icons';
import { Button } from './ui';

/** No status shows the help line. info and success are neutral; error means the driver has to change something. */
type Status = { tone: 'info' | 'success' | 'error'; text: string };
const HINT = 'Try a destination, time, total budget, and walking limit. Your selected car determines charger fit.';
const UPDATED = 'Search updated. You can adjust any filter.';

/**
 * Natural-language search as a small panel over the top-left corner of the map. It collapses to a single button, so the
 * map stays the focus. Render it inside a positioned (`relative`) map container. A successful search applies the
 * filters and collapses the panel; anything the driver has to fix keeps it open.
 */
export default function NaturalLanguageSearch({ api, context, destination, onApply }: {
  api: DwellApi | null;
  context: SearchContext;
  destination: Destination | null;
  onApply: (intent: SearchIntent, destination: Destination | null) => void;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<Status | null>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const launcherRef = useRef<HTMLButtonElement>(null);
  const returnFocus = useRef(false);
  const [choices, setChoices] = useState<{ intent: SearchIntent; destinations: Destination[] } | null>(null);
  const requestId = useRef(0);
  // Discard responses after navigation, typing a new request, or changing the underlying selections.
  useEffect(() => {
    requestId.current++;
    setBusy(false);
    setChoices(null);
    return () => { requestId.current++; };
  }, [context.startHour, context.hours, context.destinationLabel]);

  // Opening puts the cursor in the box. Closing from inside the panel hands focus back to the button that opened it.
  useEffect(() => {
    if (open) inputRef.current?.focus();
    else if (returnFocus.current) { returnFocus.current = false; launcherRef.current?.focus(); }
  }, [open]);

  function openPanel() {
    // A finished search's confirmation belongs to the moment it happened, not to the next time the panel opens.
    setStatus((current) => (current?.tone === 'success' ? null : current));
    setOpen(true);
  }

  function closePanel() {
    returnFocus.current = true;
    setOpen(false);
  }

  /** The search worked: the page already shows the result, so get the panel out of the map's way. */
  function succeed() {
    setStatus({ tone: 'success', text: UPDATED });
    setChoices(null);
    closePanel();
  }

  /** Something needs the driver's attention: say so prominently and put the cursor back where they edit. */
  function fail(text: string) {
    setStatus({ tone: 'error', text });
    inputRef.current?.focus();
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!query.trim() || busy) return;
    const id = ++requestId.current;
    setBusy(true);
    setStatus(null);
    setChoices(null);
    try {
      const request = { query: query.trim(), context };
      const result = await parseSearch(request, api);
      if (id !== requestId.current) return;
      if (!result.ok) { fail(result.message); return; }
      const intent = result.data.intent;
      if (!isSearchIntent(intent)) { fail('The search could not be understood. Try again or use the search filters.'); return; }
      if (intent.clarification) { fail(intent.clarification); return; }
      if (!intent.destinationQuery) {
        if (intent.maxWalkMinutes !== null && !destination) { fail('Choose a destination in the To field so we can estimate the walk.'); return; }
        onApply(intent, destination);
        succeed();
        return;
      }
      const destinations = await resolveSearchDestination(intent.destinationQuery);
      if (id !== requestId.current) return;
      if (destinations.length === 0) { fail('No matching destination in Massachusetts. Try a T station or a more specific address.'); return; }
      if (destinations.length > 1) { setChoices({ intent, destinations }); setStatus({ tone: 'info', text: 'Choose the destination you meant:' }); return; }
      onApply(intent, destinations[0]);
      succeed();
    } catch (error) {
      if (id === requestId.current) fail(error instanceof Error ? error.message : 'Search assistance is unavailable. Use the search filters.');
    } finally {
      if (id === requestId.current) setBusy(false);
    }
  }

  const failed = status?.tone === 'error';

  return (
    <div className="absolute left-3 top-3 z-30 max-w-[calc(100%-1.5rem)]">
      {/* The polite region stays mounted, even while the panel is closed, so the result of a search is announced. */}
      <p role="status" aria-live="polite" className="sr-only">{status?.tone === 'success' ? status.text : ''}</p>

      {!open ? (
        <button
          ref={launcherRef} type="button" aria-expanded={false} aria-controls="ai-charger-panel" onClick={openPanel}
          className="inline-flex h-11 items-center gap-2 rounded-full border border-line-strong bg-paper px-4 text-[15px] font-semibold text-ink shadow-panel transition-colors hover:border-brand hover:bg-brand-wash focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand"
        >
          <span className="text-brand"><Sparkle size={18} /></span>
          Describe your plans
        </button>
      ) : (
        <section
          id="ai-charger-panel" role="dialog" aria-labelledby="ai-charger-title"
          onKeyDown={(e) => { if (e.key === 'Escape') { e.stopPropagation(); closePanel(); } }}
          className="w-[344px] max-w-full rounded-card border border-line-strong bg-paper p-3.5 shadow-panel"
        >
          <div className="mb-2 flex items-center justify-between gap-2">
            <h2 id="ai-charger-title" className="flex items-center gap-2 text-[15px] font-semibold text-ink">
              <span className="text-brand"><Sparkle size={18} /></span>
              Describe your charging plans
            </h2>
            <button
              type="button" aria-label="Close" onClick={closePanel}
              className="-mr-1 inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-muted transition-colors hover:bg-surface hover:text-ink focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-brand"
            >
              <Close size={18} />
            </button>
          </div>

          <form onSubmit={submit} className="flex flex-col gap-2.5" aria-busy={busy}>
            <label htmlFor="ai-charger-search" className="sr-only">Describe your charging plans</label>
            <textarea
              ref={inputRef} id="ai-charger-search" rows={3} value={query} maxLength={SEARCH_QUERY_MAX_LENGTH} autoComplete="off"
              aria-invalid={failed ? true : undefined}
              aria-describedby={failed ? 'ai-charger-search-error' : 'ai-charger-search-status'}
              placeholder="Near Central Square today, 2–5 p.m., under $15 total, within a 10-minute walk"
              className={`resize-none py-2.5 leading-[1.45] ${failed ? 'border-amber-ink' : 'border-line-strong'} ${CONTROL}`}
              onChange={(e) => { requestId.current++; setQuery(e.target.value); setBusy(false); setChoices(null); setStatus(null); }}
              // Enter searches; Shift+Enter would add a line, which a search description never needs, so it is left alone.
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); e.currentTarget.form?.requestSubmit(); }
              }}
            />
            <Button type="submit" size="nav" className="w-full" disabled={busy || !query.trim()}>{busy ? 'Finding your filters…' : 'Find chargers with AI'}</Button>
          </form>

          {/* The status text is the field's description; an error replaces it with an alert. */}
          <p id="ai-charger-search-status" role="status" aria-live="polite" className="mt-2.5 text-[13px] text-body empty:mt-0">
            {failed ? '' : (status?.text ?? HINT)}
          </p>
          {failed && (
            <div id="ai-charger-search-error" role="alert" className="mt-2.5 flex items-start gap-2 rounded-card bg-amber-bg px-3 py-2.5 text-[14px] font-medium text-amber-ink">
              <span className="mt-0.5 shrink-0"><Warn size={16} /></span>
              <p>{status.text}</p>
            </div>
          )}
          {choices && (
            <div className="mt-2.5 flex flex-wrap gap-2" role="group" aria-label="Matching destinations">
              {choices.destinations.map((d) => (
                <Button key={d.id} variant="secondary" size="nav" onClick={() => { onApply(choices.intent, d); succeed(); }}>{d.label}</Button>
              ))}
            </div>
          )}
        </section>
      )}
    </div>
  );
}

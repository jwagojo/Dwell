import type { Evaluation, SortMode } from './evaluateListing';

export const SEARCH_QUERY_MAX_LENGTH = 1000;
export const AI_SEARCH_TIMEOUT_MS = 25_000;

export interface SearchContext {
  startHour: number;
  hours: number;
  destinationLabel: string | null;
}

/** Null scheduling/destination fields retain current selections; null limits mean unlimited. */
export interface SearchIntent {
  destinationQuery: string | null;
  date: string | null;
  startHour: number | null;
  hours: number | null;
  maxTotalUsd: number | null;
  budgetExclusive: boolean;
  maxWalkMinutes: number | null;
  level: 'any' | 'L1' | 'L2' | null;
  sort: SortMode | null;
  clarification: string | null;
}

export interface ParseSearchRequest {
  query: string;
  context: SearchContext;
}

export interface SearchLimits {
  maxTotalUsd: number | null;
  budgetExclusive: boolean;
  maxWalkMinutes: number | null;
}

export const NO_SEARCH_LIMITS: SearchLimits = { maxTotalUsd: null, budgetExclusive: false, maxWalkMinutes: null };

/** Uses the fee-inclusive booking total and fails closed when walking distance is unknown. */
export function matchesSearchLimits(e: Evaluation, limits: SearchLimits): boolean {
  if (limits.maxTotalUsd !== null && (limits.budgetExclusive ? e.total >= limits.maxTotalUsd : e.total > limits.maxTotalUsd)) return false;
  return limits.maxWalkMinutes === null || (e.walkMinutes !== null && e.walkMinutes <= limits.maxWalkMinutes);
}

const isObj = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v);
const textOrNull = (v: unknown, max: number) => v === null || (typeof v === 'string' && v.trim().length > 0 && v.length <= max);
const numberOrNull = (v: unknown) => v === null || (typeof v === 'number' && Number.isFinite(v));
const KEYS = ['destinationQuery', 'date', 'startHour', 'hours', 'maxTotalUsd', 'budgetExclusive', 'maxWalkMinutes', 'level', 'sort', 'clarification'];

/** Validate model output again at the API boundary, including when using native structured outputs. */
export function isSearchIntent(v: unknown): v is SearchIntent {
  return isObj(v) && Object.keys(v).length === KEYS.length && KEYS.every((k) => k in v) &&
    textOrNull(v.destinationQuery, 200) && textOrNull(v.date, 40) &&
    numberOrNull(v.startHour) && numberOrNull(v.hours) && numberOrNull(v.maxTotalUsd) &&
    typeof v.budgetExclusive === 'boolean' && numberOrNull(v.maxWalkMinutes) &&
    (v.level === null || v.level === 'any' || v.level === 'L1' || v.level === 'L2') &&
    (v.sort === null || v.sort === 'fit' || v.sort === 'price') && textOrNull(v.clarification, 500);
}

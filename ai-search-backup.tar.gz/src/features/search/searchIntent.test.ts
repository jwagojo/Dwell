import { describe, expect, it, vi } from 'vitest';
import { evaluateListing } from './evaluateListing';
import { matchesSearchLimits, NO_SEARCH_LIMITS } from './searchIntent';
import { resolveSearchDestination } from './resolveDestination';
import type { Car, Listing } from '../../types/listing';
import type { GeocodedAddress } from '../../adapters/geocodingTypes';

const car: Car = { id: 'leaf', name: 'Leaf', plug: 'J1772', maxAcKw: 6.6 };
const listing: Listing = { id: 'l1', title: 'Driveway', street: 'Pearl St', neighborhood: 'Cambridge', lat: 42.3654, lng: -71.1031, spotType: 'Driveway', chargerKw: 9.6, level: 'L2', plug: 'J1772', adapters: 'NONE', solarKw: 0, spots: 1, hostName: 'Host', rate: .3, earningsHr: 1.5, windows: [{ id: 'w1', days: [0], start: 0, end: 23 }], instructions: '', photos: [] };

describe('AI search filtering', () => {
  it('compares the fee-inclusive total, rather than hourly price or the subtotal', () => {
    const e = evaluateListing(listing, car, listing, { startHour: 14, hours: 3, dayIndex: 0 })!;
    expect(e.total).toBe(11.48);
    expect(matchesSearchLimits(e, { ...NO_SEARCH_LIMITS, maxTotalUsd: 11 })).toBe(false);
    expect(matchesSearchLimits(e, { ...NO_SEARCH_LIMITS, maxTotalUsd: e.total })).toBe(true);
    expect(matchesSearchLimits(e, { ...NO_SEARCH_LIMITS, maxTotalUsd: e.total, budgetExclusive: true })).toBe(false);
  });

  it('requires a known walk for a walking limit, and preserves results without limits', () => {
    const e = evaluateListing(listing, car, null, { startHour: 14, hours: 3, dayIndex: 0 })!;
    expect(matchesSearchLimits(e, NO_SEARCH_LIMITS)).toBe(true);
    expect(matchesSearchLimits(e, { ...NO_SEARCH_LIMITS, maxWalkMinutes: 10 })).toBe(false);
    expect(matchesSearchLimits({ ...e, walkMinutes: 10 }, { ...NO_SEARCH_LIMITS, maxWalkMinutes: 10 })).toBe(true);
    expect(matchesSearchLimits({ ...e, walkMinutes: 11 }, { ...NO_SEARCH_LIMITS, maxWalkMinutes: 10 })).toBe(false);
  });
});

describe('AI destination resolution', () => {
  it('resolves a known station and locality without a network call', async () => {
    const lookup = vi.fn();
    expect(await resolveSearchDestination('Central Square, Cambridge, MA', lookup)).toMatchObject([{ id: 'central', lat: 42.3654, lng: -71.1031 }]);
    expect(lookup).not.toHaveBeenCalled();
  });

  it('keeps ambiguous geocoded results for user selection and filters out other states', async () => {
    const address = (id: string, state: string) => ({ id, label: id, state, country: 'US', lat: 42.36, lng: -71.1 } as GeocodedAddress);
    const lookup = vi.fn().mockResolvedValue({ ok: true, results: [address('one', 'MA'), address('two', 'MA'), address('other', 'NH')] });
    expect((await resolveSearchDestination('Harvard University', lookup)).map((d) => d.id)).toEqual(['one', 'two']);
    expect(lookup).toHaveBeenCalledOnce();
  });
});

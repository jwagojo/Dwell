import { searchAddresses, DESTINATION_TYPES, isMassachusetts } from '../../adapters/addressSearch';
import { addressToDestination, stationToDestination } from '../../data/destinations';
import { STATIONS } from '../../data/stations';
import type { Destination } from '../../types/destination';

const normalize = (s: string) => s.toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();

/** Coordinates are resolved from reference data or a geocoder, never from model output. */
export async function resolveSearchDestination(query: string, lookup = searchAddresses): Promise<Destination[]> {
  const q = normalize(query);
  const station = STATIONS.find((s) => [s.name, s.id, ...(s.aliases ?? [])].some((name) =>
    [name, `${name} ${s.group}`, `${name} ${s.group} MA`, `${name} ${s.group} Massachusetts`].some((variant) => normalize(variant) === q),
  ));
  if (station) return [stationToDestination(station)];
  const result = await lookup(query, { types: DESTINATION_TYPES });
  if (!result.ok) throw new Error('The destination lookup could not connect. Try again or choose a destination in the To field.');
  return result.results.filter(isMassachusetts).map(addressToDestination);
}

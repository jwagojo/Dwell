import { afterEach, describe, expect, it, vi } from 'vitest';
import { parseLocalSearch, parseSearch } from './aiSearch';

const request = { query: 'Central Square at 2 p.m.', context: { startHour: 14, hours: 3, destinationLabel: null } };
const intent = { destinationQuery: 'Central Square', date: null, startHour: 14, hours: 3, maxTotalUsd: null, budgetExclusive: false, maxWalkMinutes: null, level: null, sort: null, clarification: null };
afterEach(() => { vi.unstubAllGlobals(); vi.unstubAllEnvs(); });

describe('AI search transport selection', () => {
  it('uses same-origin Vite middleware during development even with a configured AWS backend', async () => {
    vi.stubEnv('DEV', true);
    const fetchMock = vi.fn().mockResolvedValue(new Response(JSON.stringify({ intent })));
    vi.stubGlobal('fetch', fetchMock);
    const api = { parseSearch: vi.fn() };
    expect(await parseSearch(request, api)).toMatchObject({ ok: true, data: { intent } });
    expect(api.parseSearch).not.toHaveBeenCalled();
    expect(fetchMock.mock.calls[0][0]).toBe('/__dev/search/parse');
    const init = fetchMock.mock.calls[0][1];
    expect(init.headers).toEqual({ 'content-type': 'application/json' });
    expect(JSON.parse(init.body)).toEqual(request);
  });

  it('uses the same local endpoint in prototype development', async () => {
    vi.stubEnv('DEV', true);
    const fetchMock = vi.fn().mockResolvedValue(new Response(JSON.stringify({ intent })));
    vi.stubGlobal('fetch', fetchMock);
    expect((await parseSearch(request, null)).ok).toBe(true);
    expect(fetchMock.mock.calls[0][0]).toBe('/__dev/search/parse');
  });

  it('uses the authenticated API in production and never attempts the development route', async () => {
    vi.stubEnv('DEV', false);
    const fetchMock = vi.fn();
    vi.stubGlobal('fetch', fetchMock);
    const result = { ok: true, status: 200, data: { intent } };
    const api = { parseSearch: vi.fn().mockResolvedValue(result) };
    expect(await parseSearch(request, api)).toEqual(result);
    expect(api.parseSearch).toHaveBeenCalledWith(request);
    expect(fetchMock).not.toHaveBeenCalled();
    expect(await parseLocalSearch(request)).toMatchObject({ ok: false, code: 'AI_NOT_CONFIGURED' });
    expect(await parseSearch(request, null)).toMatchObject({ ok: false, code: 'AI_NOT_CONFIGURED' });
  });

  it('preserves actionable local errors and recovers from a missing middleware response', async () => {
    vi.stubEnv('DEV', true);
    const fetchMock = vi.fn().mockResolvedValueOnce(new Response(JSON.stringify({ error: { code: 'AI_AUTH', message: 'Connection needs checking.' } }), { status: 503 }))
      .mockResolvedValueOnce(new Response('<!doctype html>'));
    vi.stubGlobal('fetch', fetchMock);
    expect(await parseSearch(request, null)).toMatchObject({ ok: false, code: 'AI_AUTH', message: 'Connection needs checking.' });
    expect(await parseSearch(request, null)).toMatchObject({ ok: false, code: 'AI_LOCAL_ROUTE_MISSING', message: expect.stringContaining('Restart the dev server') });
  });
});

import { AI_SEARCH_TIMEOUT_MS, isSearchIntent, type ParseSearchRequest, type SearchIntent } from '../features/search/searchIntent';
import type { ApiResult, DwellApi } from './dwellApi';

const unavailable = (): ApiResult<{ intent: SearchIntent }> => ({ ok: false, status: 503, code: 'AI_NOT_CONFIGURED', message: 'Search assistance is unavailable. Use the search filters.', details: {} });

/** Local AI uses the Vite server even when config.json points other features at a deployed backend. */
export async function parseSearch(request: ParseSearchRequest, api: Pick<DwellApi, 'parseSearch'> | null): Promise<ApiResult<{ intent: SearchIntent }>> {
  if (import.meta.env.DEV) return parseLocalSearch(request);
  return api ? api.parseSearch(request) : unavailable();
}

/** Vite serves this only during development. Production calls the Cognito-protected API instead. */
export async function parseLocalSearch(request: ParseSearchRequest): Promise<ApiResult<{ intent: SearchIntent }>> {
  if (!import.meta.env.DEV) return unavailable();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), AI_SEARCH_TIMEOUT_MS);
  try {
    const response = await fetch('/__dev/search/parse', {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(request), signal: controller.signal,
    });
    let body: unknown;
    try { body = await response.json(); }
    catch (error) {
      if (controller.signal.aborted) throw error;
      return { ok: false, status: response.status, code: 'AI_LOCAL_ROUTE_MISSING', message: 'The local search service has not loaded. Restart the dev server, then refresh this page.', details: {} };
    }
    if (typeof body !== 'object' || body === null || Array.isArray(body)) {
      return { ok: false, status: response.status, code: 'AI_BAD_RESPONSE', message: 'The search service returned an invalid response. Try again or use the search filters.', details: {} };
    }
    const result = body as { intent?: unknown; error?: { code?: string; message?: string } };
    if (response.ok && isSearchIntent(result.intent)) return { ok: true, status: response.status, data: { intent: result.intent } };
    return { ok: false, status: response.status, code: typeof result.error?.code === 'string' ? result.error.code : 'AI_BAD_RESPONSE', message: typeof result.error?.message === 'string' ? result.error.message : 'Search assistance is unavailable. Use the search filters.', details: {} };
  } catch {
    return { ok: false, status: 0, code: controller.signal.aborted ? 'TIMEOUT' : 'NETWORK', message: 'Search assistance could not connect. Try again or use the search filters.', details: {} };
  } finally { clearTimeout(timer); }
}

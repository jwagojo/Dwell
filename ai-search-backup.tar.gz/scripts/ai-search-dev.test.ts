import type { ViteDevServer } from 'vite';
import type { IncomingMessage, ServerResponse } from 'node:http';
import { Readable } from 'node:stream';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { aiSearchDevPlugin } from './ai-search-dev';

const input = { query: 'Central Square, 2 p.m. for 3 hours', context: { startHour: 14, hours: 3, destinationLabel: null } };
const intent = { destinationQuery: 'Central Square', date: null, startHour: 14, hours: 3, maxTotalUsd: null, budgetExclusive: false, maxWalkMinutes: null, level: null, sort: null, clarification: null };

beforeEach(() => {
  // Keep the tests independent of whatever the developer has exported in their shell.
  for (const name of ['OLLAMA_BASE_URL', 'OLLAMA_MODEL', 'OPENAI_API_KEY', 'OPENAI_MODEL', 'OPENAI_BASE_URL', 'OPENAI_REASONING_EFFORT']) vi.stubEnv(name, undefined);
});
afterEach(() => { vi.unstubAllGlobals(); vi.unstubAllEnvs(); vi.restoreAllMocks(); });

/** Exercise the actual middleware without opening a socket (also works in restricted runners). */
function localRequest(headers: Record<string, string>, environment: Record<string, string> = { OPENAI_API_KEY: 'dev-secret' }) {
  return new Promise<{ status: number; body: string }>((resolve, reject) => {
    const plugin = aiSearchDevPlugin(environment);
    const request = Object.assign(Readable.from([JSON.stringify(input)]), { url: '/__dev/search/parse', method: 'POST', headers: { host: 'localhost:5173', ...headers }, socket: { remoteAddress: '127.0.0.1' } }) as unknown as IncomingMessage;
    let status = 0;
    const response = { writeHead: (value: number) => { status = value; }, end: (body: string) => resolve({ status, body }) } as unknown as ServerResponse;
    const fakeServer = { middlewares: { use: (middleware: (req: IncomingMessage, res: ServerResponse, next: () => void) => void) => middleware(request, response, () => reject(new Error('Route was not handled'))) } } as unknown as ViteDevServer;
    if (typeof plugin.configureServer !== 'function') throw new Error('Missing development middleware');
    plugin.configureServer.call({} as never, fakeServer);
  });
}

describe('local AI server boundary', () => {
  it('accepts a same-origin request, sends the server secret only to the AI provider, and returns only filters', async () => {
    vi.spyOn(Date, 'now').mockReturnValue(Date.parse('2026-10-28T14:00:00Z'));
    const modelFetch = vi.fn().mockResolvedValue(new Response(JSON.stringify({ choices: [{ finish_reason: 'stop', message: { content: JSON.stringify(intent), refusal: null } }] })));
    vi.stubGlobal('fetch', modelFetch);
    const response = await localRequest({ 'content-type': 'application/json', origin: 'http://localhost:5173' });
    expect(response.status).toBe(200);
    const text = response.body;
    expect(JSON.parse(text)).toEqual({ intent });
    expect(text).not.toContain('dev-secret');
    expect(modelFetch.mock.calls[0][1].headers.authorization).toBe('Bearer dev-secret');
  });

  it('rejects a cross-origin call and non-JSON submissions before invoking the model', async () => {
    const modelFetch = vi.fn();
    vi.stubGlobal('fetch', modelFetch);
    const crossOrigin = await localRequest({ 'content-type': 'application/json', origin: 'https://unrelated.example' });
    expect(crossOrigin.status).toBe(403);
    const form = await localRequest({ 'content-type': 'text/plain' });
    expect(form.status).toBe(405);
    expect(modelFetch).not.toHaveBeenCalled();
  });
  it('uses a configured local Ollama server instead of OpenAI, sending no credential', async () => {
    vi.spyOn(Date, 'now').mockReturnValue(Date.parse('2026-10-28T14:00:00Z'));
    const modelFetch = vi.fn().mockResolvedValue(new Response(JSON.stringify({ done: true, done_reason: 'stop', message: { role: 'assistant', content: JSON.stringify(intent) } })));
    vi.stubGlobal('fetch', modelFetch);
    const response = await localRequest({ 'content-type': 'application/json', origin: 'http://localhost:5173' }, { OPENAI_API_KEY: 'dev-secret', OLLAMA_BASE_URL: 'http://localhost:11434', OLLAMA_MODEL: 'qwen3:8b' });
    expect(response.status).toBe(200);
    expect(JSON.parse(response.body)).toEqual({ intent });
    expect(modelFetch.mock.calls[0][0]).toBe('http://localhost:11434/api/chat');
    expect(JSON.stringify(modelFetch.mock.calls[0][1])).not.toContain('dev-secret');
  });

  it('reports a missing model name without calling anything', async () => {
    const modelFetch = vi.fn();
    vi.stubGlobal('fetch', modelFetch);
    vi.spyOn(console, 'warn').mockImplementation(() => undefined);
    const response = await localRequest({ 'content-type': 'application/json', origin: 'http://localhost:5173' }, { OLLAMA_BASE_URL: 'http://localhost:11434' });
    expect(response.status).toBe(503);
    expect(modelFetch).not.toHaveBeenCalled();
  });
});

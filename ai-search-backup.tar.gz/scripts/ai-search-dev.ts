import type { Plugin } from 'vite';
import { HttpError } from '../functions/shared/http';
import { interpretSearch, interpretSearchWithOllama, parseSearchRequest } from '../functions/parse-search/service';

/**
 * The service deliberately hides upstream failures from the browser. Locally, print the HTTP status and
 * the provider's short error message to the dev-server terminal so setup problems are diagnosable.
 * The request (prompt text) and the Authorization header are never printed.
 */
const loggedFetch = (provider: string): typeof fetch => async (input, init) => {
  try {
    const res = await fetch(input, init);
    if (!res.ok) {
      const detail = (await res.clone().text().catch(() => '')).replace(/\s+/g, ' ').slice(0, 300);
      console.warn(`[ai-search] ${provider} responded ${res.status}${detail ? `: ${detail}` : ''}`);
    }
    return res;
  } catch (error) {
    const cause = (error as { cause?: { code?: string } }).cause?.code;
    const hint = cause === 'ECONNREFUSED' && provider === 'Ollama' ? ' Is Ollama running? Start the Ollama app or run `ollama serve`.' : '';
    console.warn(`[ai-search] Could not reach ${provider}: ${error instanceof Error ? error.name : 'unknown error'}${cause ? ` (${cause})` : ''}.${hint}`);
    throw error;
  }
};

/** Local-only server route. This file and the token are never imported by application code. */
export function aiSearchDevPlugin(environment: Record<string, string>): Plugin {
  return {
    name: 'dwell-ai-search-dev', apply: 'serve',
    configureServer(server) {
      let inFlight = 0;
      server.middlewares.use((req, res, next) => {
        if (req.url?.split('?')[0] !== '/__dev/search/parse') return next();
        const respond = (status: number, body: unknown) => {
          res.writeHead(status, { 'content-type': 'application/json', 'cache-control': 'no-store' });
          res.end(JSON.stringify(body));
        };
        void (async () => {
          const host = req.headers.host ?? '';
          const remote = req.socket.remoteAddress ?? '';
          const origin = req.headers.origin;
          if (!/^(localhost|127\.0\.0\.1|\[::1\])(?::\d+)?$/.test(host) ||
            !/^(::1|127\.0\.0\.1|::ffff:127\.0\.0\.1)$/.test(remote) ||
            req.headers['sec-fetch-site'] === 'cross-site' || (origin && origin !== `http://${host}` && origin !== `https://${host}`)) {
            throw new HttpError(403, 'FORBIDDEN', 'Search assistance is available from the local app only.');
          }
          if (req.method !== 'POST' || !req.headers['content-type']?.startsWith('application/json')) throw new HttpError(405, 'METHOD', 'Use a JSON POST request.');
          if (inFlight >= 2) throw new HttpError(429, 'AI_BUSY', 'Search assistance is busy. Try again shortly.');
          const chunks: Buffer[] = [];
          let size = 0;
          for await (const chunk of req) {
            const buffer = Buffer.from(chunk);
            size += buffer.length;
            if (size > 8192) throw new HttpError(413, 'TOO_LARGE', 'The search description is too long.');
            chunks.push(buffer);
          }
          let body: unknown;
          try { body = JSON.parse(Buffer.concat(chunks).toString('utf8')); }
          catch { throw new HttpError(400, 'BAD_REQUEST', 'The request body must be JSON.'); }
          const request = parseSearchRequest(body);
          // A local Ollama server wins when configured; otherwise OpenAI with a server-side key.
          const setting = (name: string) => (process.env[name] || environment[name] || '').trim();
          const ollamaUrl = setting('OLLAMA_BASE_URL');
          const apiKey = setting('OPENAI_API_KEY');
          if (!ollamaUrl && !apiKey) throw new HttpError(503, 'AI_NOT_CONFIGURED', 'Search assistance is unavailable. Use the search filters.');
          if (ollamaUrl && !setting('OLLAMA_MODEL')) {
            console.warn('[ai-search] OLLAMA_BASE_URL is set but OLLAMA_MODEL is not. Add OLLAMA_MODEL=<a pulled model> to .env and restart.');
            throw new HttpError(503, 'AI_NOT_CONFIGURED', 'Search assistance is unavailable. Use the search filters.');
          }
          inFlight++;
          try {
            const intent = ollamaUrl
              ? await interpretSearchWithOllama(request, { baseUrl: ollamaUrl, model: setting('OLLAMA_MODEL'), fetchImpl: loggedFetch('Ollama') })
              : await interpretSearch(request, {
                token: apiKey, modelId: setting('OPENAI_MODEL') || undefined, baseUrl: setting('OPENAI_BASE_URL') || undefined,
                reasoningEffort: environment.OPENAI_REASONING_EFFORT ?? process.env.OPENAI_REASONING_EFFORT, fetchImpl: loggedFetch('OpenAI'),
              });
            respond(200, { intent });
          } finally { inFlight--; }
        })().catch((error: unknown) => {
          const safe = error instanceof HttpError ? error : new HttpError(500, 'INTERNAL', 'Search assistance is unavailable. Use the search filters.');
          respond(safe.status, { error: { code: safe.code, message: safe.message } });
        });
      });
    },
  };
}
